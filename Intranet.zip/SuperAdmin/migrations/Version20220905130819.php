<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20220905130819 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE direction DROP FOREIGN KEY FK_BCBB5310ED5CA9E6');
        $this->addSql('DROP INDEX IDX_BCBB5310ED5CA9E6 ON direction');
        $this->addSql('ALTER TABLE direction DROP service_id');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE Direction ADD service_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE Direction ADD CONSTRAINT FK_BCBB5310ED5CA9E6 FOREIGN KEY (service_id) REFERENCES service (id)');
        $this->addSql('CREATE INDEX IDX_BCBB5310ED5CA9E6 ON Direction (service_id)');
    }
}
