<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20220904225611 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE Direction (id INT AUTO_INCREMENT NOT NULL, intitule_direction VARCHAR(255) NOT NULL, statut INT NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE fos_user ADD direction_id INT DEFAULT NULL, ADD path VARCHAR(255) DEFAULT NULL');
        $this->addSql('ALTER TABLE fos_user ADD CONSTRAINT FK_957A6479AF73D997 FOREIGN KEY (direction_id) REFERENCES Direction (id)');
        $this->addSql('CREATE INDEX IDX_957A6479AF73D997 ON fos_user (direction_id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE fos_user DROP FOREIGN KEY FK_957A6479AF73D997');
        $this->addSql('DROP TABLE Direction');
        $this->addSql('DROP INDEX IDX_957A6479AF73D997 ON fos_user');
        $this->addSql('ALTER TABLE fos_user DROP direction_id, DROP path');
    }
}
