<?php

namespace App\Controller;

use App\Constante\Constantes;
use DateTime;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Exception\AuthenticationException;
use Symfony\Component\Security\Core\Security;
use Symfony\Component\Security\Csrf\CsrfTokenManagerInterface;

class AccueilController extends AbstractController
{
    private $tokenManager;

    public function __construct(CsrfTokenManagerInterface $tokenManager = null)
    {
        $this->tokenManager = $tokenManager;
    }

    /**
     * @Route("/", name="accueil")
     */
    public function accueil()
    {
        $user = $this->getUser();
        $roles = $user->getRoles();
        $role = $roles[0];
       
        return $this->render('user/accueil.html.twig', [
            'controller_name' => 'AccueilController','graphe' => null
        ]);
    }
}
