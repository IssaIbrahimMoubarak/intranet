<?php

namespace App\Controller;

use App\Constante\Constantes;
use App\Entity\Direction;
use App\Form\EditDirectionType;
use App\Form\DirectionType;
use App\Repository\DirectionRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Security;

class DirectionController extends AbstractController
{
    private $directionRepository;
    private $entityManager;
    private $tokenManager;
    private $formFactory;
    private $directionManager;

    public function __construct(DirectionRepository $directionRepository, EntityManagerInterface $entityManager)
    {
        $this->directionRepository = $directionRepository;
        $this->entityManager = $entityManager;
    }


    /**
     * @Route("/direction", name="list_direction")
     */
    public function Direction(): Response
    {
        $user = $this->getUser();
        $directions = $this->directionRepository->getDirections();
        $resultat = "";
        $classe = "";
        $roles = $user->getRoles();
        $role = $roles[0];
        if (!$directions) {
            $resultat = "";
            $classe = "";
        }
        return $this->render('direction/direction.html.twig', [
            'directions' => $directions, 'resultat' => $resultat, 'classe' => $classe
        ]);
    }

    /**
     * @Route("/direction/new", name="create_direction")
     */
    public function createDirection(Request $request): Response
    {
        $users = $this->getUser();
        $direction = new Direction();
        $resultat = "";
        $classe = "";

        $form = $this->createForm(DirectionType::class, $direction);
        $roles = $users->getRoles();
        $role = $roles[0];

        if ($request->isMethod('POST') && $form->handleRequest($request)->isValid()) {
            $data = $request->request->get($form->getName());
            $direction->setStatut(1);
            // $direction->upload();
            $this->entityManager->persist($direction);
            $this->entityManager->flush();
            if ($direction) {
                return $this->redirectToRoute('list_direction');
            } else {
                $resultat = "Echec de la creation!.";
                $classe = "alert alert-danger";
                return $this->render('direction/direction-form.html.twig', [
                    'action' => 'create',
                    'form' => $form->createView(), 'resultat' => $resultat, 'classe' => $classe
                ]);
            }
        }
        return $this->render('direction/direction-form.html.twig', [
            'action' => 'create',
            'form' => $form->createView(), 'resultat' => $resultat, 'classe' => $classe
        ]);
    }

    /**
     * @Route("/direction/edit/{id}", name="edit_direction")
     */
    public function editDirection(Request $request, Direction $direction): Response
    {
        $users = $this->getUser();
        $roles = $users->getRoles();
        $role = $roles[0];

        $form = $this->createForm(DirectionType::class, $direction);

        if ($role !== Constantes::ROLE_SUPER_ADMIN) {
            $resultat = "Vous n'avez pas l'autorisation d'accéder à cette page.";
            $classe = "alert alert-danger";
            return $this->render('direction/direction-form.html.twig', [
                'action' => 'edit',
                'direction' => $direction,
                'form' => $form->createView(), 'resultat' => $resultat, 'classe' => $classe
            ]);
        }
        $resultat = "";
        $classe = "";

        if ($request->isMethod('POST') && $form->handleRequest($request)->isValid()) {
            $this->entityManager->persist($direction);
            $this->entityManager->flush();
            if ($direction) {
                $roles = $users->getRoles();
                $primaryRole = $roles[0];
                if ($primaryRole === Constantes::ROLE_SUPER_ADMIN) {
                    return $this->redirectToRoute('list_direction');
                }
            } else {
                $resultat = "Echec de la modification!.";
                $classe = "alert alert-danger";

                return $this->render('direction/direction-form.html.twig', [
                    'action' => 'edit',
                    'direction' => $direction,
                    'form' => $form->createView(), 'resultat' => $resultat, 'classe' => $classe
                ]);
            }
        }
        return $this->render('direction/direction-form.html.twig', [
            'action' => 'edit',
            'direction' => $direction,
            'form' => $form->createView(), 'resultat' => $resultat, 'classe' => $classe
        ]);
    }

    /**
     * @Route("/desactiver/{id}", name="desabled_direction")
     */

    public function desactiverDirection(Request $request, Direction $direction_entity): Response

    {
        $user = $this->getUser();
        $roles = $user->getRoles();
        $role = $roles[0];
        $entityManager = $this->getDoctrine()->getManager();
        if ($role !== Constantes::ROLE_SUPER_ADMIN) {

            return $this->render('direction/direction.html.twig', [
                'direction' => null,
            ]);
        }
        $direction_entity->setStatut(0);
        $entityManager->persist($direction_entity);
        $entityManager->flush();
        $directions = $this->directionRepository->getDirections();

        if ($entityManager) {
            return $this->redirectToRoute('list_direction');
        } else {
            return $this->render('direction/direction.html.twig', [
                'directions' => $directions,
            ]);
        }

        return $this->render('direction/direction.html.twig', [
            'directions' => $directions,
        ]);
    }

    /**
     * @Route("/activer/{id}", name="enable_direction")
     */

    public function activerDirection(Request $request, Direction $direction_entity): Response

    {
        $user = $this->getUser();
        $roles = $user->getRoles();
        $role = $roles[0];
        $entityManager = $this->getDoctrine()->getManager();
        if ($role !== Constantes::ROLE_SUPER_ADMIN) {

            return $this->render('direction/direction.html.twig', [
                'direction' => null,
            ]);
        }
        $direction_entity->setStatut(1);
        $entityManager->persist($direction_entity);
        $entityManager->flush();
        $directions = $this->directionRepository->getDirections();

        if ($entityManager) {
            return $this->redirectToRoute('list_direction');
        } else {
            return $this->render('direction/direction.html.twig', [
                'directions' => $directions,
            ]);
        }

        return $this->render('direction/direction.html.twig', [
            'directions' => $directions,
        ]);
    }
}
