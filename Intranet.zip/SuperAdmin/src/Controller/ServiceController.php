<?php

namespace App\Controller;

use App\Constante\Constantes;
use App\Entity\Service;
use App\Form\EditServiceType;
use App\Form\ServiceType;
use App\Repository\ServiceRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Security;

class ServiceController extends AbstractController
{
    private $serviceRepository;
    private $entityManager;
    private $tokenManager;
    private $formFactory;
    private $serviceManager;

    public function __construct(ServiceRepository $serviceRepository, EntityManagerInterface $entityManager)
    {
        $this->serviceRepository = $serviceRepository;
        $this->entityManager = $entityManager;
    }


    /**
     * @Route("/service", name="list_service")
     */
    public function Service(): Response
    {
        $user = $this->getUser();
        $services = $this->serviceRepository->getServices();
        $resultat = "";
        $classe = "";
        $roles = $user->getRoles();
        $role = $roles[0];
        if (!$services) {
            $resultat = "";
            $classe = "";
        }
        return $this->render('service/service.html.twig', [
            'services' => $services, 'resultat' => $resultat, 'classe' => $classe
        ]);
    }

    /**
     * @Route("/service/new", name="create_service")
     */
    public function createService(Request $request): Response
    {
        $users = $this->getUser();
        $service = new Service();
        $resultat = "";
        $classe = "";

        $form = $this->createForm(ServiceType::class, $service);
        $roles = $users->getRoles();
        $role = $roles[0];

        if ($request->isMethod('POST') && $form->handleRequest($request)->isValid()) {
            $data = $request->request->get($form->getName());
            $service->setStatut(1);
            // $service->upload();
            $this->entityManager->persist($service);
            $this->entityManager->flush();
            if ($service) {
                return $this->redirectToRoute('list_service');
            } else {
                $resultat = "Echec de la creation!.";
                $classe = "alert alert-danger";
                return $this->render('service/service-form.html.twig', [
                    'action' => 'create',
                    'form' => $form->createView(), 'resultat' => $resultat, 'classe' => $classe
                ]);
            }
        }
        return $this->render('service/service-form.html.twig', [
            'action' => 'create',
            'form' => $form->createView(), 'resultat' => $resultat, 'classe' => $classe
        ]);
    }

    /**
     * @Route("/service/edit/{id}", name="edit_service")
     */
    public function editService(Request $request, Service $service): Response
    {
        $users = $this->getUser();
        $roles = $users->getRoles();
        $role = $roles[0];

        $form = $this->createForm(ServiceType::class, $service);

        if ($role !== Constantes::ROLE_SUPER_ADMIN) {
            $resultat = "Vous n'avez pas l'autorisation d'accéder à cette page.";
            $classe = "alert alert-danger";
            return $this->render('service/service-form.html.twig', [
                'action' => 'edit',
                'service' => $service,
                'form' => $form->createView(), 'resultat' => $resultat, 'classe' => $classe
            ]);
        }
        $resultat = "";
        $classe = "";

        if ($request->isMethod('POST') && $form->handleRequest($request)->isValid()) {
            $this->entityManager->persist($service);
            $this->entityManager->flush();
            if ($service) {
                $roles = $users->getRoles();
                $primaryRole = $roles[0];
                if ($primaryRole === Constantes::ROLE_SUPER_ADMIN) {
                    return $this->redirectToRoute('list_service');
                }
            } else {
                $resultat = "Echec de la modification!.";
                $classe = "alert alert-danger";

                return $this->render('service/service-form.html.twig', [
                    'action' => 'edit',
                    'service' => $service,
                    'form' => $form->createView(), 'resultat' => $resultat, 'classe' => $classe
                ]);
            }
        }
        return $this->render('service/service-form.html.twig', [
            'action' => 'edit',
            'service' => $service,
            'form' => $form->createView(), 'resultat' => $resultat, 'classe' => $classe
        ]);
    }

    /**
     * @Route("/desactiver/{id}", name="desabled_service")
     */

    public function desactiverService(Request $request, Service $service_entity): Response

    {
        $user = $this->getUser();
        $roles = $user->getRoles();
        $role = $roles[0];
        $entityManager = $this->getDoctrine()->getManager();
        if ($role !== Constantes::ROLE_SUPER_ADMIN) {

            return $this->render('service/service.html.twig', [
                'service' => null,
            ]);
        }
        $service_entity->setStatut(0);
        $entityManager->persist($service_entity);
        $entityManager->flush();
        $services = $this->serviceRepository->getServices();

        if ($entityManager) {
            return $this->redirectToRoute('list_service');
        } else {
            return $this->render('service/service.html.twig', [
                'services' => $services,
            ]);
        }

        return $this->render('service/service.html.twig', [
            'services' => $services,
        ]);
    }

    /**
     * @Route("/activer/{id}", name="enable_service")
     */

    public function activerService(Request $request, Service $service_entity): Response

    {
        $user = $this->getUser();
        $roles = $user->getRoles();
        $role = $roles[0];
        $entityManager = $this->getDoctrine()->getManager();
        if ($role !== Constantes::ROLE_SUPER_ADMIN) {

            return $this->render('service/service.html.twig', [
                'service' => null,
            ]);
        }
        $service_entity->setStatut(1);
        $entityManager->persist($service_entity);
        $entityManager->flush();
        $services = $this->serviceRepository->getServices();

        if ($entityManager) {
            return $this->redirectToRoute('list_service');
        } else {
            return $this->render('service/service.html.twig', [
                'services' => $services,
            ]);
        }

        return $this->render('service/service.html.twig', [
            'services' => $services,
        ]);
    }
}
