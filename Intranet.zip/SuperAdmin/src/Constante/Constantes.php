<?php

namespace App\Constante;

class Constantes
{

    const ROLE_SUPER_ADMIN = "ROLE_SUPER_ADMIN";
    const ROLE_ADMIN = "ROLE_ADMIN";
    const ROLE_AGENT = "ROLE_AGENT";
}
