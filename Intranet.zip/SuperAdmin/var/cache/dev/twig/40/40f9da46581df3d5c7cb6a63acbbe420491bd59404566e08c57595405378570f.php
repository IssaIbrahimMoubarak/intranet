<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* chef/chef.html.twig */
class __TwigTemplate_b5afce5fa96b0f876f724b727a9843aae5d375b5c92c22e38024dc1cb2585d68 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'autresfichierscss' => [$this, 'block_autresfichierscss'],
            'content' => [$this, 'block_content'],
            'autresFichiersJs' => [$this, 'block_autresFichiersJs'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "layout_main.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "chef/chef.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "chef/chef.html.twig"));

        $this->parent = $this->loadTemplate("layout_main.html.twig", "chef/chef.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Chef de direction
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 4
    public function block_autresfichierscss($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "autresfichierscss"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "autresfichierscss"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "\t<!-- Content Header (Page header) -->
\t<section class=\"content-header\">
\t\t<div class=\"container-fluid\">
\t\t\t<div class=\"row mb-2\">
\t\t\t\t<div class=\"col-sm-6\">
\t\t\t\t\t<h1>Liste des chefs des directions</h1>
\t\t\t\t\t";
        // line 12
        if (array_key_exists("classe", $context)) {
            // line 13
            echo "\t\t\t\t\t\t<div class=\"";
            echo twig_escape_filter($this->env, (isset($context["classe"]) || array_key_exists("classe", $context) ? $context["classe"] : (function () { throw new RuntimeError('Variable "classe" does not exist.', 13, $this->source); })()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["resultat"]) || array_key_exists("resultat", $context) ? $context["resultat"] : (function () { throw new RuntimeError('Variable "resultat" does not exist.', 13, $this->source); })()), "html", null, true);
            echo "</div>
\t\t\t\t\t";
        }
        // line 15
        echo "\t\t\t\t</div>
\t\t\t\t<div class=\"col-sm-6\">
\t\t\t\t\t<ol class=\"breadcrumb float-sm-right\">
\t\t\t\t\t\t<li class=\"breadcrumb-item\">
\t\t\t\t\t\t\t<a href=\"#\">Accueil</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li class=\"breadcrumb-item active\">Liste des chefs des directions</li>
\t\t\t\t\t</ol>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<!-- /.container-fluid -->
\t</section>

\t<!-- Main content -->
\t<section class=\"content\">
\t\t<div class=\"container-fluid\">
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-12\">
\t\t\t\t\t<div class=\"card\">
\t\t\t\t\t\t<div class=\"card-header\">
\t\t\t\t\t\t\t<h3 class=\"card-title\">Tableau de liste des chefs des directions</h3>
\t\t\t\t\t\t\t<div class=\"card-tools\">
\t\t\t\t\t\t\t\t";
        // line 38
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted((isset($context["role_superAdmin"]) || array_key_exists("role_superAdmin", $context) ? $context["role_superAdmin"] : (function () { throw new RuntimeError('Variable "role_superAdmin" does not exist.', 38, $this->source); })()))) {
            // line 39
            echo "\t\t\t\t\t\t\t\t\t<div class=\"input-group input-group-sm\">
\t\t\t\t\t\t\t\t\t\t<a class=\"btn btn-success btn-sm ml-3\" href=\"";
            // line 40
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("create_chef");
            echo "\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-plus\"></i>
\t\t\t\t\t\t\t\t\t\t\tAjouter un chef de direction
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
        }
        // line 46
        echo "\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<!-- /.card-header -->
\t\t\t\t\t\t<div class=\"card-body\">
\t\t\t\t\t\t\t<table id=\"user\" class=\"table table-bordered table-striped\">
\t\t\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<th>Id</th>
\t\t\t\t\t\t\t\t\t\t<th>Login</th>
\t\t\t\t\t\t\t\t\t\t<th>Nom et prénom</th>
\t\t\t\t\t\t\t\t\t\t<th>E-mail</th>
\t\t\t\t\t\t\t\t\t\t<th>Telephone</th>
\t\t\t\t\t\t\t\t\t\t<th>Direction</th>
\t\t\t\t\t\t\t\t\t\t<th>Actions</th>
\t\t\t\t\t\t\t\t\t\t<th>Desactiver</th>

\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t</thead>
\t\t\t\t\t\t\t\t<tbody>


\t\t\t\t\t\t\t\t\t";
        // line 67
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["users"]) || array_key_exists("users", $context) ? $context["users"] : (function () { throw new RuntimeError('Variable "users" does not exist.', 67, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
            // line 68
            echo "
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td>";
            // line 70
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "id", [], "any", false, false, false, 70), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t<td>";
            // line 71
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "username", [], "any", false, false, false, 71), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t<td>";
            // line 72
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "firstName", [], "any", false, false, false, 72), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 73
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "lastName", [], "any", false, false, false, 73), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t<td>";
            // line 74
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "email", [], "any", false, false, false, 74), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t<td>";
            // line 75
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "telephone", [], "any", false, false, false, 75), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t<td>";
            // line 76
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "direction", [], "any", false, false, false, 76), "html", null, true);
            echo "</td>

\t\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t\t\t<a class=\"btn btn-info btn-sm\" href=\"";
            // line 79
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("edit_chef", ["id" => twig_get_attribute($this->env, $this->source, $context["user"], "id", [], "any", false, false, false, 79)]), "html", null, true);
            echo "\" onclick=\"return confirm('Etes-vous sûr de vouloir modifier ce chef de direction ?')\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-edit\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"sr-only\">Editer</span>
\t\t\t\t\t\t\t\t\t\t\t\t</a>

\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 86
            if ((twig_get_attribute($this->env, $this->source, $context["user"], "enabled", [], "any", false, false, false, 86) == 1)) {
                // line 87
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<a class=\"btn btn-danger btn-sm\" href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("desabled_chef", ["id" => twig_get_attribute($this->env, $this->source, $context["user"], "id", [], "any", false, false, false, 87)]), "html", null, true);
                echo "\" onclick=\"return confirm('Etes-vous sûr de vouloir desactiver ce chef de direction ?')\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-edit\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"sr-only\">Delete</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 92
            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t";
            if ((twig_get_attribute($this->env, $this->source, $context["user"], "enabled", [], "any", false, false, false, 92) == 0)) {
                // line 93
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a class=\"btn btn-success btn-sm\" href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("enable_chef", ["id" => twig_get_attribute($this->env, $this->source, $context["user"], "id", [], "any", false, false, false, 93)]), "html", null, true);
                echo "\" onclick=\"return confirm('Etes-vous sûr de vouloir activer ce chef de direction ?')\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-edit\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"sr-only\">Activate</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 98
            echo "\t\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t</tr>

\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 103
        echo "\t\t\t\t\t\t\t\t</tbody>

\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<!-- /.card-body -->
\t\t\t\t\t</div>
\t\t\t\t\t<!-- /.card -->

\t\t\t\t</div>
\t\t\t\t<!-- /.col -->
\t\t\t</div>
\t\t\t<!-- /.row -->
\t\t</div>

\t\t<!-- /.container-fluid -->
\t</section>
\t<!-- /.content -->

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 122
    public function block_autresFichiersJs($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "autresFichiersJs"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "autresFichiersJs"));

        // line 123
        echo "\t<!-- jQuery -->
\t<script src=\"";
        // line 124
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/jquery/jquery.min.js"), "html", null, true);
        echo "\"></script>
\t<!-- Bootstrap 4 -->
\t<script src=\"";
        // line 126
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/bootstrap/js/bootstrap.bundle.min.js"), "html", null, true);
        echo "\"></script>
\t<!-- DataTables  & Plugins -->
\t<script src=\"";
        // line 128
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/datatables/jquery.dataTables.min.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 129
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 130
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/datatables-responsive/js/dataTables.responsive.min.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 131
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/datatables-responsive/js/responsive.bootstrap4.min.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 132
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/datatables-buttons/js/dataTables.buttons.min.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 133
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/datatables-buttons/js/buttons.bootstrap4.min.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 134
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/jszip/jszip.min.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 135
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/pdfmake/pdfmake.min.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 136
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/pdfmake/vfs_fonts.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 137
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/datatables-buttons/js/buttons.html5.min.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 138
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/datatables-buttons/js/buttons.print.min.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 139
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/datatables-buttons/js/buttons.colVis.min.js"), "html", null, true);
        echo "\"></script>
\t<!-- AdminLTE App -->
\t<script src=\"";
        // line 141
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dist/js/adminlte.min.js"), "html", null, true);
        echo "\"></script>
\t<!-- AdminLTE for demo purposes -->
\t<script src=\"";
        // line 143
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dist/js/demo.js"), "html", null, true);
        echo "\"></script>
\t<!-- Page specific script -->
\t<script>
\t\t\$(function () {
\$(\"#user\").DataTable({
\"responsive\": true,
\"aaSorting\": [
[0, \"desc\"]
],
oLanguage: {
sSearch: \"Rechercher : \",
sZeroRecords: \"Aucune valeur trouvée\",
sInfo: \"Afficher page _PAGE_ sur _PAGES_\",
sInfoFiltered: \"(Filtres sur _MAX_ )\",
sInfoEmpty: \"\",
oPaginate: {
sFirst: \"Premier\",
sPrevious: \"Pr&eacute;c&eacute;dent\",
sNext: \"Suivant\",
sLast: \"Dernier\"
}
},
\"lengthChange\": false,
\"autoWidth\": false,
\"buttons\": [
\"copy\",
\"csv\",
\"excel\",
\"pdf\",
\"print\",
\"colvis\"
]
}).buttons().container().appendTo('#user_wrapper .col-md-6:eq(0)');

});
\t</script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "chef/chef.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  375 => 143,  370 => 141,  365 => 139,  361 => 138,  357 => 137,  353 => 136,  349 => 135,  345 => 134,  341 => 133,  337 => 132,  333 => 131,  329 => 130,  325 => 129,  321 => 128,  316 => 126,  311 => 124,  308 => 123,  298 => 122,  270 => 103,  260 => 98,  251 => 93,  248 => 92,  239 => 87,  237 => 86,  227 => 79,  221 => 76,  217 => 75,  213 => 74,  209 => 73,  205 => 72,  201 => 71,  197 => 70,  193 => 68,  189 => 67,  166 => 46,  157 => 40,  154 => 39,  152 => 38,  127 => 15,  119 => 13,  117 => 12,  109 => 6,  99 => 5,  81 => 4,  61 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'layout_main.html.twig' %}
{% block title %}Chef de direction
{% endblock %}
{% block autresfichierscss %}{% endblock %}
{% block content %}
\t<!-- Content Header (Page header) -->
\t<section class=\"content-header\">
\t\t<div class=\"container-fluid\">
\t\t\t<div class=\"row mb-2\">
\t\t\t\t<div class=\"col-sm-6\">
\t\t\t\t\t<h1>Liste des chefs des directions</h1>
\t\t\t\t\t{% if classe is defined %}
\t\t\t\t\t\t<div class=\"{{classe}}\">{{resultat}}</div>
\t\t\t\t\t{% endif %}
\t\t\t\t</div>
\t\t\t\t<div class=\"col-sm-6\">
\t\t\t\t\t<ol class=\"breadcrumb float-sm-right\">
\t\t\t\t\t\t<li class=\"breadcrumb-item\">
\t\t\t\t\t\t\t<a href=\"#\">Accueil</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li class=\"breadcrumb-item active\">Liste des chefs des directions</li>
\t\t\t\t\t</ol>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<!-- /.container-fluid -->
\t</section>

\t<!-- Main content -->
\t<section class=\"content\">
\t\t<div class=\"container-fluid\">
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-12\">
\t\t\t\t\t<div class=\"card\">
\t\t\t\t\t\t<div class=\"card-header\">
\t\t\t\t\t\t\t<h3 class=\"card-title\">Tableau de liste des chefs des directions</h3>
\t\t\t\t\t\t\t<div class=\"card-tools\">
\t\t\t\t\t\t\t\t{% if is_granted(role_superAdmin) %}
\t\t\t\t\t\t\t\t\t<div class=\"input-group input-group-sm\">
\t\t\t\t\t\t\t\t\t\t<a class=\"btn btn-success btn-sm ml-3\" href=\"{{ path('create_chef') }}\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-plus\"></i>
\t\t\t\t\t\t\t\t\t\t\tAjouter un chef de direction
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<!-- /.card-header -->
\t\t\t\t\t\t<div class=\"card-body\">
\t\t\t\t\t\t\t<table id=\"user\" class=\"table table-bordered table-striped\">
\t\t\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<th>Id</th>
\t\t\t\t\t\t\t\t\t\t<th>Login</th>
\t\t\t\t\t\t\t\t\t\t<th>Nom et prénom</th>
\t\t\t\t\t\t\t\t\t\t<th>E-mail</th>
\t\t\t\t\t\t\t\t\t\t<th>Telephone</th>
\t\t\t\t\t\t\t\t\t\t<th>Direction</th>
\t\t\t\t\t\t\t\t\t\t<th>Actions</th>
\t\t\t\t\t\t\t\t\t\t<th>Desactiver</th>

\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t</thead>
\t\t\t\t\t\t\t\t<tbody>


\t\t\t\t\t\t\t\t\t{% for user in users %}

\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<td>{{ user.id }}</td>
\t\t\t\t\t\t\t\t\t\t\t<td>{{ user.username }}</td>
\t\t\t\t\t\t\t\t\t\t\t<td>{{ user.firstName }}
\t\t\t\t\t\t\t\t\t\t\t\t{{ user.lastName }}</td>
\t\t\t\t\t\t\t\t\t\t\t<td>{{ user.email }}</td>
\t\t\t\t\t\t\t\t\t\t\t<td>{{ user.telephone }}</td>
\t\t\t\t\t\t\t\t\t\t\t<td>{{ user.direction }}</td>

\t\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t\t\t<a class=\"btn btn-info btn-sm\" href=\"{{ path('edit_chef', {id: user.id}) }}\" onclick=\"return confirm('Etes-vous sûr de vouloir modifier ce chef de direction ?')\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-edit\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"sr-only\">Editer</span>
\t\t\t\t\t\t\t\t\t\t\t\t</a>

\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t\t\t{% if user.enabled == 1 %}
\t\t\t\t\t\t\t\t\t\t\t\t\t<a class=\"btn btn-danger btn-sm\" href=\"{{ path('desabled_chef', {id: user.id}) }}\" onclick=\"return confirm('Etes-vous sûr de vouloir desactiver ce chef de direction ?')\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-edit\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"sr-only\">Delete</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t{% endif%}
\t\t\t\t\t\t\t\t\t\t\t\t\t{% if user.enabled == 0 %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a class=\"btn btn-success btn-sm\" href=\"{{ path('enable_chef', {id: user.id}) }}\" onclick=\"return confirm('Etes-vous sûr de vouloir activer ce chef de direction ?')\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-edit\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"sr-only\">Activate</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t</tr>

\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t</tbody>

\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<!-- /.card-body -->
\t\t\t\t\t</div>
\t\t\t\t\t<!-- /.card -->

\t\t\t\t</div>
\t\t\t\t<!-- /.col -->
\t\t\t</div>
\t\t\t<!-- /.row -->
\t\t</div>

\t\t<!-- /.container-fluid -->
\t</section>
\t<!-- /.content -->

{% endblock %}
{% block autresFichiersJs %}
\t<!-- jQuery -->
\t<script src=\"{{ asset('plugins/jquery/jquery.min.js') }}\"></script>
\t<!-- Bootstrap 4 -->
\t<script src=\"{{ asset('plugins/bootstrap/js/bootstrap.bundle.min.js') }}\"></script>
\t<!-- DataTables  & Plugins -->
\t<script src=\"{{ asset('plugins/datatables/jquery.dataTables.min.js') }}\"></script>
\t<script src=\"{{ asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js') }}\"></script>
\t<script src=\"{{ asset('plugins/datatables-responsive/js/dataTables.responsive.min.js') }}\"></script>
\t<script src=\"{{ asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js') }}\"></script>
\t<script src=\"{{ asset('plugins/datatables-buttons/js/dataTables.buttons.min.js') }}\"></script>
\t<script src=\"{{ asset('plugins/datatables-buttons/js/buttons.bootstrap4.min.js') }}\"></script>
\t<script src=\"{{ asset('plugins/jszip/jszip.min.js') }}\"></script>
\t<script src=\"{{ asset('plugins/pdfmake/pdfmake.min.js') }}\"></script>
\t<script src=\"{{ asset('plugins/pdfmake/vfs_fonts.js') }}\"></script>
\t<script src=\"{{ asset('plugins/datatables-buttons/js/buttons.html5.min.js') }}\"></script>
\t<script src=\"{{ asset('plugins/datatables-buttons/js/buttons.print.min.js') }}\"></script>
\t<script src=\"{{ asset('plugins/datatables-buttons/js/buttons.colVis.min.js') }}\"></script>
\t<!-- AdminLTE App -->
\t<script src=\"{{ asset('dist/js/adminlte.min.js') }}\"></script>
\t<!-- AdminLTE for demo purposes -->
\t<script src=\"{{ asset('dist/js/demo.js') }}\"></script>
\t<!-- Page specific script -->
\t<script>
\t\t\$(function () {
\$(\"#user\").DataTable({
\"responsive\": true,
\"aaSorting\": [
[0, \"desc\"]
],
oLanguage: {
sSearch: \"Rechercher : \",
sZeroRecords: \"Aucune valeur trouvée\",
sInfo: \"Afficher page _PAGE_ sur _PAGES_\",
sInfoFiltered: \"(Filtres sur _MAX_ )\",
sInfoEmpty: \"\",
oPaginate: {
sFirst: \"Premier\",
sPrevious: \"Pr&eacute;c&eacute;dent\",
sNext: \"Suivant\",
sLast: \"Dernier\"
}
},
\"lengthChange\": false,
\"autoWidth\": false,
\"buttons\": [
\"copy\",
\"csv\",
\"excel\",
\"pdf\",
\"print\",
\"colvis\"
]
}).buttons().container().appendTo('#user_wrapper .col-md-6:eq(0)');

});
\t</script>
{% endblock %}
", "chef/chef.html.twig", "E:\\mes projets\\SuperAdmin\\templates\\chef\\chef.html.twig");
    }
}
