<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* user/accueil.html.twig */
class __TwigTemplate_6e18dc4fb3989c50d9191233a2c75112a9ba79e71a96b496baad0df9c02fcd2d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "layout_main.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "user/accueil.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "user/accueil.html.twig"));

        $this->parent = $this->loadTemplate("layout_main.html.twig", "user/accueil.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "\t";
        // line 380
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "user/accueil.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  70 => 380,  68 => 3,  58 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'layout_main.html.twig' %}
{% block content %}
\t{# <section class=\"content-header\">
\t    <div class=\"row\">
\t\t\t
\t\t\t\t<div class=\"col-lg-3 col-6\">
\t\t\t\t  <!-- small box -->
\t\t\t\t  <div class=\"small-box bg-info\">
\t\t\t\t\t<div class=\"inner\">
\t\t\t\t\t\t<h3>0 </h3>
\t\t\t\t\t  <p>Montant avance</p>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"icon\">
\t\t\t\t\t  <!--<i class=\"ion ion-bag\"></i>-->
\t\t\t\t\t  <i class=\"ion ion-stats-bars\"></i>
\t\t\t\t\t</div>
\t\t\t\t
\t\t\t\t  </div>
\t\t\t\t</div>
\t\t\t\t<!-- ./col -->
\t\t\t\t<div class=\"col-lg-3 col-6\">
\t\t\t\t  <!-- small box -->
\t\t\t\t  <div class=\"small-box bg-success\">
\t\t\t\t\t<div class=\"inner\">
\t\t\t\t\t  <!--<h3>53<sup style=\"font-size: 20px\">%</sup></h3>-->
\t\t\t\t\t  <h3>0</h3>
\t\t\t\t\t
\t  
\t\t\t\t\t  <p>Montant restant</p>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"icon\">
\t\t\t\t\t  <i class=\"ion ion-stats-bars\"></i>
\t\t\t\t\t</div>
\t\t\t\t
\t\t\t\t  </div>
\t\t\t\t</div>
\t\t\t\t<!-- ./col -->
\t\t\t\t<div class=\"col-lg-3 col-6\">
\t\t\t\t  <!-- small box -->
\t\t\t\t  <div class=\"small-box bg-warning\">
\t\t\t\t\t<div class=\"inner\">
\t\t\t\t\t\t<h3>0 </h3>
\t\t\t\t\t
\t  
\t\t\t\t\t  <p>Montant global</p>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"icon\">
\t\t\t\t\t  <!--<i class=\"ion ion-person-add\"></i>-->
\t\t\t\t\t  <i class=\"ion ion-stats-bars\"></i>
\t\t\t\t\t</div>
\t\t\t\t
\t\t\t\t  </div>
\t\t\t\t</div>
\t\t\t\t
\t\t\t\t<!-- ./col -->
\t\t\t\t<!-- ./col -->
\t\t\t  </div>
\t
\t\t\t
\t\t\t<!-- /.row -->
\t\t\t<script src=\"{{ asset('plugins/jquery/jquery.min.js') }}\"></script>
\t\t\t<script src=\"{{ asset('plugins/bootstrap/js/bootstrap.bundle.min.js') }}\"></script>
\t\t\t<script src=\"{{ asset('plugins/chart.js/Chart.min.js') }}\"></script>
\t\t\t<script src=\"{{ asset('dist/js/adminlte.min.js') }}\"></script>
\t\t\t<script src=\"{{ asset('dist/js/demo.js') }}\"></script>
\t\t
\t\t<!-- AdminLTE App -->
\t\t<!-- AdminLTE for demo purposes -->
\t\t<!-- page script -->
\t\t<script>
\t\t\t\$(function () {
\t\t  
\t\t\t  var labels = [];
\t\t\t  var data = [];
\t\t\t  var graphe = 'areaChart';
\t\t\t  var grapheb = 'barChart';
\t\t\t\tvar dataconsommes = [];
\t\t\t  //alert(labels);
\t
\t\t\t  
\t\t\t\tvar areaChartCanvas = \$('#areaChart1').get(0).getContext('2d')
\t\t\t\t
\t\t\t  //var labels = ['janvier 2021','fevrier 2021','mars 2021']
\t\t\t  //var data = [800000,60000,800000];
\t\t\t  var areaChartData = {
\t\t  
\t\t\t\t
\t\t\t\tlabels  :   labels,
\t\t\t\tdatasets: [
\t\t\t\t  {
\t\t\t\t\tlabel               : 'Nombre de bons émis',
\t\t\t\t\tbackgroundColor     : 'rgba(60,141,188,0.9)',
\t\t\t\t\tborderColor         : 'rgba(60,141,188,0.8)',
\t\t\t\t\tpointRadius          : false,
\t\t\t\t\tpointColor          : '#3b8bba',
\t\t\t\t\tpointStrokeColor    : 'rgba(60,141,188,1)',
\t\t\t\t\tpointHighlightFill  : '#fff',
\t\t\t\t\tpointHighlightStroke: 'rgba(60,141,188,1)',
\t\t\t\t\tdata                : data
\t\t\t\t  },
\t\t\t\t  /*{
\t\t\t\t\tlabel               : 'Montant de bons emis',
\t\t\t\t\tbackgroundColor     : 'rgba(210, 214, 222, 1)',
\t\t\t\t\tborderColor         : 'rgba(210, 214, 222, 1)',
\t\t\t\t\tpointRadius         : false,
\t\t\t\t\tpointColor          : 'rgba(210, 214, 222, 1)',
\t\t\t\t\tpointStrokeColor    : '#c1c7d1',
\t\t\t\t\tpointHighlightFill  : '#fff',
\t\t\t\t\tpointHighlightStroke: 'rgba(220,220,220,1)',
\t\t\t\t\tdata                : dataconsommes
\t\t\t\t  },*/
\t\t\t\t]
\t\t\t  }
\t\t  
\t\t\t  var areaChartOptions = {
\t\t\t\tmaintainAspectRatio : false,
\t\t\t\tresponsive : true,
\t\t\t\tlegend: {
\t\t\t\t  display: true
\t\t\t\t},
\t\t\t\tscales: {
\t\t\t\t  xAxes: [{
\t\t\t\t\tgridLines : {
\t\t\t\t\t  display : false,
\t\t\t\t\t}
\t\t\t\t  }],
\t\t\t\t  yAxes: [{
\t\t\t\t\tgridLines : {
\t\t\t\t\t  display : false,
\t\t\t\t\t}
\t\t\t\t  }]
\t\t\t\t}
\t\t\t  }
\t\t  
\t\t\t  var areaChart       = new Chart(areaChartCanvas, {
\t\t\t\ttype: 'line',
\t\t\t\tdata: areaChartData,
\t\t\t\toptions: areaChartOptions
\t\t\t  })
\t\t  
\t
\t\t\t  var areaChartCanvas = \$('#areaChart2').get(0).getContext('2d')
\t\t\t\t
\t\t\t 
\t\t\t  //var labels = ['janvier 2021','fevrier 2021','mars 2021']
\t\t\t  //var data = [800000,60000,800000];
\t\t\t  var areaChartData = {
\t\t  
\t\t\t\t
\t\t\t\tlabels  :   labels,
\t\t\t\tdatasets: [
\t\t\t\t  {
\t\t\t\t\tlabel               : 'Montant de bons émis',
\t\t\t\t\tbackgroundColor     : 'rgba(60,141,188,0.9)',
\t\t\t\t\tborderColor         : 'rgba(60,141,188,0.8)',
\t\t\t\t\tpointRadius          : false,
\t\t\t\t\tpointColor          : '#3b8bba',
\t\t\t\t\tpointStrokeColor    : 'rgba(60,141,188,1)',
\t\t\t\t\tpointHighlightFill  : '#fff',
\t\t\t\t\tpointHighlightStroke: 'rgba(60,141,188,1)',
\t\t\t\t\tdata                : data
\t\t\t\t  },
\t\t\t\t  /*{
\t\t\t\t\tlabel               : 'Montant de bons emis',
\t\t\t\t\tbackgroundColor     : 'rgba(210, 214, 222, 1)',
\t\t\t\t\tborderColor         : 'rgba(210, 214, 222, 1)',
\t\t\t\t\tpointRadius         : false,
\t\t\t\t\tpointColor          : 'rgba(210, 214, 222, 1)',
\t\t\t\t\tpointStrokeColor    : '#c1c7d1',
\t\t\t\t\tpointHighlightFill  : '#fff',
\t\t\t\t\tpointHighlightStroke: 'rgba(220,220,220,1)',
\t\t\t\t\tdata                : dataconsommes
\t\t\t\t  },*/
\t\t\t\t]
\t\t\t  }
\t\t  
\t\t\t  var areaChartOptions = {
\t\t\t\tmaintainAspectRatio : false,
\t\t\t\tresponsive : true,
\t\t\t\tlegend: {
\t\t\t\t  display: true
\t\t\t\t},
\t\t\t\tscales: {
\t\t\t\t  xAxes: [{
\t\t\t\t\tgridLines : {
\t\t\t\t\t  display : false,
\t\t\t\t\t}
\t\t\t\t  }],
\t\t\t\t  yAxes: [{
\t\t\t\t\tgridLines : {
\t\t\t\t\t  display : false,
\t\t\t\t\t}
\t\t\t\t  }]
\t\t\t\t}
\t\t\t  }
\t\t  
\t\t\t  var areaChart       = new Chart(areaChartCanvas, {
\t\t\t\ttype: 'line',
\t\t\t\tdata: areaChartData,
\t\t\t\toptions: areaChartOptions
\t\t\t  })
\t\t\t  
\t\t\t  var areaChartCanvas = \$('#areaChart3').get(0).getContext('2d')
\t\t\t  
\t\t\t 
\t\t\t  //var labels = ['janvier 2021','fevrier 2021','mars 2021']
\t\t\t  //var data = [800000,60000,800000];
\t\t\t  var areaChartData = {
\t\t  
\t\t\t\t
\t\t\t\tlabels  :   labels,
\t\t\t\tdatasets: [
\t\t\t\t  {
\t\t\t\t\tlabel               : 'Nombre de bons consommés',
\t\t\t\t\tbackgroundColor     : 'rgba(60,141,188,0.9)',
\t\t\t\t\tborderColor         : 'rgba(60,141,188,0.8)',
\t\t\t\t\tpointRadius          : false,
\t\t\t\t\tpointColor          : '#3b8bba',
\t\t\t\t\tpointStrokeColor    : 'rgba(60,141,188,1)',
\t\t\t\t\tpointHighlightFill  : '#fff',
\t\t\t\t\tpointHighlightStroke: 'rgba(60,141,188,1)',
\t\t\t\t\tdata                : dataconsommes
\t\t\t\t  },
\t\t\t\t  /*{
\t\t\t\t\tlabel               : 'Montant de bons emis',
\t\t\t\t\tbackgroundColor     : 'rgba(210, 214, 222, 1)',
\t\t\t\t\tborderColor         : 'rgba(210, 214, 222, 1)',
\t\t\t\t\tpointRadius         : false,
\t\t\t\t\tpointColor          : 'rgba(210, 214, 222, 1)',
\t\t\t\t\tpointStrokeColor    : '#c1c7d1',
\t\t\t\t\tpointHighlightFill  : '#fff',
\t\t\t\t\tpointHighlightStroke: 'rgba(220,220,220,1)',
\t\t\t\t\tdata                : dataconsommes
\t\t\t\t  },*/
\t\t\t\t]
\t\t\t  }
\t\t  
\t\t\t  var areaChartOptions = {
\t\t\t\tmaintainAspectRatio : false,
\t\t\t\tresponsive : true,
\t\t\t\tlegend: {
\t\t\t\t  display: true
\t\t\t\t},
\t\t\t\tscales: {
\t\t\t\t  xAxes: [{
\t\t\t\t\tgridLines : {
\t\t\t\t\t  display : false,
\t\t\t\t\t}
\t\t\t\t  }],
\t\t\t\t  yAxes: [{
\t\t\t\t\tgridLines : {
\t\t\t\t\t  display : false,
\t\t\t\t\t}
\t\t\t\t  }]
\t\t\t\t}
\t\t\t  }
\t\t  
\t\t\t  var areaChart       = new Chart(areaChartCanvas, {
\t\t\t\ttype: 'line',
\t\t\t\tdata: areaChartData,
\t\t\t\toptions: areaChartOptions
\t\t\t  })
\t
\t\t\t  var areaChartCanvas = \$('#areaChart4').get(0).getContext('2d')
\t\t\t  
\t\t\t 
\t\t\t  //var labels = ['janvier 2021','fevrier 2021','mars 2021']
\t\t\t  //var data = [800000,60000,800000];
\t\t\t  var areaChartData = {
\t\t  
\t\t\t\t
\t\t\t\tlabels  :   labels,
\t\t\t\tdatasets: [
\t\t\t\t  {
\t\t\t\t\tlabel               : 'Montant de bons consommés',
\t\t\t\t\tbackgroundColor     : 'rgba(60,141,188,0.9)',
\t\t\t\t\tborderColor         : 'rgba(60,141,188,0.8)',
\t\t\t\t\tpointRadius          : false,
\t\t\t\t\tpointColor          : '#3b8bba',
\t\t\t\t\tpointStrokeColor    : 'rgba(60,141,188,1)',
\t\t\t\t\tpointHighlightFill  : '#fff',
\t\t\t\t\tpointHighlightStroke: 'rgba(60,141,188,1)',
\t\t\t\t\tdata                : dataconsommes
\t\t\t\t  },
\t\t\t\t  /*{
\t\t\t\t\tlabel               : 'Montant de bons emis',
\t\t\t\t\tbackgroundColor     : 'rgba(210, 214, 222, 1)',
\t\t\t\t\tborderColor         : 'rgba(210, 214, 222, 1)',
\t\t\t\t\tpointRadius         : false,
\t\t\t\t\tpointColor          : 'rgba(210, 214, 222, 1)',
\t\t\t\t\tpointStrokeColor    : '#c1c7d1',
\t\t\t\t\tpointHighlightFill  : '#fff',
\t\t\t\t\tpointHighlightStroke: 'rgba(220,220,220,1)',
\t\t\t\t\tdata                : dataconsommes
\t\t\t\t  },*/
\t\t\t\t]
\t\t\t  }
\t\t  
\t\t\t  var areaChartOptions = {
\t\t\t\tmaintainAspectRatio : false,
\t\t\t\tresponsive : true,
\t\t\t\tlegend: {
\t\t\t\t  display: true
\t\t\t\t},
\t\t\t\tscales: {
\t\t\t\t  xAxes: [{
\t\t\t\t\tgridLines : {
\t\t\t\t\t  display : false,
\t\t\t\t\t}
\t\t\t\t  }],
\t\t\t\t  yAxes: [{
\t\t\t\t\tgridLines : {
\t\t\t\t\t  display : false,
\t\t\t\t\t}
\t\t\t\t  }]
\t\t\t\t}
\t\t\t  }
\t\t  
\t\t\t  var areaChart       = new Chart(areaChartCanvas, {
\t\t\t\ttype: 'line',
\t\t\t\tdata: areaChartData,
\t\t\t\toptions: areaChartOptions
\t\t\t  })
\t
\t\t\t
\t\t\t if(graphe =='donutChart'){
\t\t\t  var donutChartCanvas = \$('#donutChart').get(0).getContext('2d')
\t\t\t  var donutData        = {
\t\t\t\tlabels: labels,
\t\t\t\tdatasets: [
\t\t\t\t  {
\t\t\t\t\tdata: data,
\t\t\t\t\tbackgroundColor : ['#f56954', '#00a65a'],
\t\t\t\t  }
\t\t\t\t]
\t\t\t  }
\t\t\t 
\t\t\t  var donutOptions     = {
\t\t\t\tmaintainAspectRatio : false,
\t\t\t\tresponsive : true,
\t\t\t  }
\t\t\t  //Create pie or douhnut chart
\t\t\t  // You can switch between pie and douhnut using the method below.
\t\t\t  var donutChart = new Chart(donutChartCanvas, {
\t\t\t\ttype: 'doughnut',
\t\t\t\tdata: donutData,
\t\t\t\toptions: donutOptions
\t\t\t  })
\t\t  
\t\t\t  //---------------------
\t\t\t  //- STACKED BAR CHART -
\t\t\t  //---------------------
\t\t\t  var stackedBarChartCanvas = \$('#stackedBarChart').get(0).getContext('2d')
\t\t\t  var stackedBarChartData = jQuery.extend(true, {}, barChartData)
\t\t  
\t\t\t  var stackedBarChartOptions = {
\t\t\t\tresponsive              : true,
\t\t\t\tmaintainAspectRatio     : false,
\t\t\t\tscales: {
\t\t\t\t  xAxes: [{
\t\t\t\t\tstacked: true,
\t\t\t\t  }],
\t\t\t\t  yAxes: [{
\t\t\t\t\tstacked: true
\t\t\t\t  }]
\t\t\t\t}
\t\t\t  }
\t\t  
\t\t\t  var stackedBarChart = new Chart(stackedBarChartCanvas, {
\t\t\t\ttype: 'bar',
\t\t\t\tdata: stackedBarChartData,
\t\t\t\toptions: stackedBarChartOptions
\t\t\t  })
\t\t\t  }else{
\t\t\t\t//rien a faire
\t\t\t  }
\t\t\t  
\t\t\t})
\t\t  </script> #}

{% endblock %}
", "user/accueil.html.twig", "E:\\mes projets\\SuperAdmin\\templates\\user\\accueil.html.twig");
    }
}
