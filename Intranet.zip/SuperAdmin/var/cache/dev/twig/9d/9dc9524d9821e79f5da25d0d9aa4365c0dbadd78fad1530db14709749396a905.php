<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* service/service.html.twig */
class __TwigTemplate_a10c9cdb350a17c045ddebcf9c1ed3757929f36f182f764ea06dea3be6c8f33f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'autresfichierscss' => [$this, 'block_autresfichierscss'],
            'content' => [$this, 'block_content'],
            'autresFichiersJs' => [$this, 'block_autresFichiersJs'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "layout_main.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "service/service.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "service/service.html.twig"));

        $this->parent = $this->loadTemplate("layout_main.html.twig", "service/service.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Liste des services
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 4
    public function block_autresfichierscss($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "autresfichierscss"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "autresfichierscss"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "\t<!-- Content Header (Page header) -->
\t<section class=\"content-header\">
\t\t<div class=\"container-fluid\">
\t\t\t<div class=\"row mb-2\">
\t\t\t\t<div class=\"col-sm-6\">
\t\t\t\t\t<h1>Liste services</h1>
\t\t\t\t\t";
        // line 12
        if (array_key_exists("classe", $context)) {
            // line 13
            echo "\t\t\t\t\t\t<div class=\"";
            echo twig_escape_filter($this->env, (isset($context["classe"]) || array_key_exists("classe", $context) ? $context["classe"] : (function () { throw new RuntimeError('Variable "classe" does not exist.', 13, $this->source); })()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["resultat"]) || array_key_exists("resultat", $context) ? $context["resultat"] : (function () { throw new RuntimeError('Variable "resultat" does not exist.', 13, $this->source); })()), "html", null, true);
            echo "</div>
\t\t\t\t\t";
        }
        // line 15
        echo "\t\t\t\t</div>
\t\t\t\t<div class=\"col-sm-6\">
\t\t\t\t\t<ol class=\"breadcrumb float-sm-right\">
\t\t\t\t\t\t<li class=\"breadcrumb-item\">
\t\t\t\t\t\t\t<a href=\"#\">Accueil</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li class=\"breadcrumb-item active\">Liste des services</li>
\t\t\t\t\t</ol>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<!-- /.container-fluid -->
\t</section>

\t<!-- Main content -->
\t<section class=\"content\">
\t\t<div class=\"container-fluid\">
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-12\">
\t\t\t\t\t<div class=\"card\">
\t\t\t\t\t\t<div class=\"card-header\">
\t\t\t\t\t\t\t<h3 class=\"card-title\">Tableau des services</h3>
\t\t\t\t\t\t\t<div class=\"card-tools\">
\t\t\t\t\t\t\t\t";
        // line 38
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted((isset($context["role_superAdmin"]) || array_key_exists("role_superAdmin", $context) ? $context["role_superAdmin"] : (function () { throw new RuntimeError('Variable "role_superAdmin" does not exist.', 38, $this->source); })()))) {
            // line 39
            echo "\t\t\t\t\t\t\t\t\t<div class=\"input-group input-group-sm\">
\t\t\t\t\t\t\t\t\t\t<a class=\"btn btn-success btn-sm ml-3\" href=\"";
            // line 40
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("create_service");
            echo "\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-plus\"></i>
\t\t\t\t\t\t\t\t\t\t\tNouveau service
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
        }
        // line 46
        echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<!-- /.card-header -->
\t\t\t\t\t\t\t<div class=\"card-body\">
\t\t\t\t\t\t\t\t<table id=\"service\" class=\"table table-bordered table-striped\">
\t\t\t\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<th>Id</th>
\t\t\t\t\t\t\t\t\t\t\t<th>Direction</th>
\t\t\t\t\t\t\t\t\t\t\t<th>Service</th>
\t\t\t\t\t\t\t\t\t\t\t<th>Actions</th>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t</thead>
\t\t\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t\t\t";
        // line 60
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["services"]) || array_key_exists("services", $context) ? $context["services"] : (function () { throw new RuntimeError('Variable "services" does not exist.', 60, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["service"]) {
            // line 61
            echo "\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<td>";
            // line 62
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["service"], "id", [], "any", false, false, false, 62), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td>";
            // line 63
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["service"], "direction", [], "any", false, false, false, 63), "intituleDirection", [], "any", false, false, false, 63), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td>";
            // line 64
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["service"], "intituleService", [], "any", false, false, false, 64), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<a class=\"btn btn-info btn-sm\" href=\"";
            // line 66
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("edit_service", ["id" => twig_get_attribute($this->env, $this->source, $context["service"], "id", [], "any", false, false, false, 66)]), "html", null, true);
            echo "\" onclick=\"return confirm('Etes-vous sûr de vouloir modifier ce service ?')\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\tModifier
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-edit\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"sr-only\">Editer</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t</a>


\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 73
            if ((twig_get_attribute($this->env, $this->source, $context["service"], "statut", [], "any", false, false, false, 73) == 1)) {
                // line 74
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a class=\"btn btn-danger btn-sm\" href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("desabled_service", ["id" => twig_get_attribute($this->env, $this->source, $context["service"], "id", [], "any", false, false, false, 74)]), "html", null, true);
                echo "\" onclick=\"return confirm('Etes-vous sûr de vouloir desactiver ce service ?')\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tSupprimer
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-lock\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"sr-only\">delete</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 80
            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t";
            if ((twig_get_attribute($this->env, $this->source, $context["service"], "statut", [], "any", false, false, false, 80) == 0)) {
                // line 81
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a class=\"btn btn-success btn-sm\" href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("enable_service", ["id" => twig_get_attribute($this->env, $this->source, $context["service"], "id", [], "any", false, false, false, 81)]), "html", null, true);
                echo "\" onclick=\"return confirm('Etes-vous sûr de vouloir activer ce service ?')\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tActiver
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-unlock\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"sr-only\">activate</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 87
            echo "\t\t\t\t\t\t\t\t\t\t\t\t</td>


\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['service'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 92
        echo "\t\t\t\t\t\t\t\t\t</tbody>

\t\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<!-- /.card-body -->
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<!-- /.card -->

\t\t\t\t\t</div>
\t\t\t\t\t<!-- /.col -->
\t\t\t\t</div>
\t\t\t\t<!-- /.row -->
\t\t\t</div>

\t\t\t<!-- /.container-fluid -->
\t\t</section>
\t\t<!-- /.content -->

\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 111
    public function block_autresFichiersJs($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "autresFichiersJs"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "autresFichiersJs"));

        // line 112
        echo "\t\t<!-- jQuery -->
\t\t<script src=\"";
        // line 113
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/jquery/jquery.min.js"), "html", null, true);
        echo "\"></script>
\t\t<!-- Bootstrap 4 -->
\t\t<script src=\"";
        // line 115
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/bootstrap/js/bootstrap.bundle.min.js"), "html", null, true);
        echo "\"></script>
\t\t<!-- DataTables  & Plugins -->
\t\t<script src=\"";
        // line 117
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/datatables/jquery.dataTables.min.js"), "html", null, true);
        echo "\"></script>
\t\t<script src=\"";
        // line 118
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"), "html", null, true);
        echo "\"></script>
\t\t<script src=\"";
        // line 119
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/datatables-responsive/js/dataTables.responsive.min.js"), "html", null, true);
        echo "\"></script>
\t\t<script src=\"";
        // line 120
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/datatables-responsive/js/responsive.bootstrap4.min.js"), "html", null, true);
        echo "\"></script>
\t\t<script src=\"";
        // line 121
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/datatables-buttons/js/dataTables.buttons.min.js"), "html", null, true);
        echo "\"></script>
\t\t<script src=\"";
        // line 122
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/datatables-buttons/js/buttons.bootstrap4.min.js"), "html", null, true);
        echo "\"></script>
\t\t<script src=\"";
        // line 123
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/jszip/jszip.min.js"), "html", null, true);
        echo "\"></script>
\t\t<script src=\"";
        // line 124
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/pdfmake/pdfmake.min.js"), "html", null, true);
        echo "\"></script>
\t\t<script src=\"";
        // line 125
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/pdfmake/vfs_fonts.js"), "html", null, true);
        echo "\"></script>
\t\t<script src=\"";
        // line 126
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/datatables-buttons/js/buttons.html5.min.js"), "html", null, true);
        echo "\"></script>
\t\t<script src=\"";
        // line 127
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/datatables-buttons/js/buttons.print.min.js"), "html", null, true);
        echo "\"></script>
\t\t<script src=\"";
        // line 128
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("plugins/datatables-buttons/js/buttons.colVis.min.js"), "html", null, true);
        echo "\"></script>
\t\t<!-- AdminLTE App -->
\t\t<script src=\"";
        // line 130
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dist/js/adminlte.min.js"), "html", null, true);
        echo "\"></script>
\t\t<!-- AdminLTE for demo purposes -->
\t\t<script src=\"";
        // line 132
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dist/js/demo.js"), "html", null, true);
        echo "\"></script>
\t\t<!-- Page specific script -->
\t\t<script>
\t\t\t\$(function () {
\$(\"#service\").DataTable({
\"responsive\": true,
\"aaSorting\": [
[0, \"desc\"]
],
oLanguage: {
sSearch: \"Rechercher : \",
sZeroRecords: \"Aucune valeur trouvée\",
sInfo: \"Afficher page _PAGE_ sur _PAGES_\",
sInfoFiltered: \"(Filtres sur _MAX_ )\",
sInfoEmpty: \"\",
oPaginate: {
sFirst: \"Premier\",
sPrevious: \"Pr&eacute;c&eacute;dent\",
sNext: \"Suivant\",
sLast: \"Dernier\"
}
},
\"lengthChange\": false,
\"autoWidth\": false,
\"buttons\": [
\"copy\",
\"csv\",
\"excel\",
\"pdf\",
\"print\",
\"colvis\"
]
}).buttons().container().appendTo('#service_wrapper .col-md-6:eq(0)');

});
\t\t</script>
\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "service/service.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  352 => 132,  347 => 130,  342 => 128,  338 => 127,  334 => 126,  330 => 125,  326 => 124,  322 => 123,  318 => 122,  314 => 121,  310 => 120,  306 => 119,  302 => 118,  298 => 117,  293 => 115,  288 => 113,  285 => 112,  275 => 111,  247 => 92,  237 => 87,  227 => 81,  224 => 80,  214 => 74,  212 => 73,  202 => 66,  197 => 64,  193 => 63,  189 => 62,  186 => 61,  182 => 60,  166 => 46,  157 => 40,  154 => 39,  152 => 38,  127 => 15,  119 => 13,  117 => 12,  109 => 6,  99 => 5,  81 => 4,  61 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'layout_main.html.twig' %}
{% block title %}Liste des services
{% endblock %}
{% block autresfichierscss %}{% endblock %}
{% block content %}
\t<!-- Content Header (Page header) -->
\t<section class=\"content-header\">
\t\t<div class=\"container-fluid\">
\t\t\t<div class=\"row mb-2\">
\t\t\t\t<div class=\"col-sm-6\">
\t\t\t\t\t<h1>Liste services</h1>
\t\t\t\t\t{% if classe is defined %}
\t\t\t\t\t\t<div class=\"{{classe}}\">{{resultat}}</div>
\t\t\t\t\t{% endif %}
\t\t\t\t</div>
\t\t\t\t<div class=\"col-sm-6\">
\t\t\t\t\t<ol class=\"breadcrumb float-sm-right\">
\t\t\t\t\t\t<li class=\"breadcrumb-item\">
\t\t\t\t\t\t\t<a href=\"#\">Accueil</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li class=\"breadcrumb-item active\">Liste des services</li>
\t\t\t\t\t</ol>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<!-- /.container-fluid -->
\t</section>

\t<!-- Main content -->
\t<section class=\"content\">
\t\t<div class=\"container-fluid\">
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-12\">
\t\t\t\t\t<div class=\"card\">
\t\t\t\t\t\t<div class=\"card-header\">
\t\t\t\t\t\t\t<h3 class=\"card-title\">Tableau des services</h3>
\t\t\t\t\t\t\t<div class=\"card-tools\">
\t\t\t\t\t\t\t\t{%if is_granted(role_superAdmin) %}
\t\t\t\t\t\t\t\t\t<div class=\"input-group input-group-sm\">
\t\t\t\t\t\t\t\t\t\t<a class=\"btn btn-success btn-sm ml-3\" href=\"{{ path('create_service') }}\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-plus\"></i>
\t\t\t\t\t\t\t\t\t\t\tNouveau service
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t{%endif%}
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<!-- /.card-header -->
\t\t\t\t\t\t\t<div class=\"card-body\">
\t\t\t\t\t\t\t\t<table id=\"service\" class=\"table table-bordered table-striped\">
\t\t\t\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<th>Id</th>
\t\t\t\t\t\t\t\t\t\t\t<th>Direction</th>
\t\t\t\t\t\t\t\t\t\t\t<th>Service</th>
\t\t\t\t\t\t\t\t\t\t\t<th>Actions</th>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t</thead>
\t\t\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t\t\t{% for service in services %}
\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<td>{{ service.id }}</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td>{{ service.direction.intituleDirection }}</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td>{{ service.intituleService }}</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<a class=\"btn btn-info btn-sm\" href=\"{{ path('edit_service', {id: service.id}) }}\" onclick=\"return confirm('Etes-vous sûr de vouloir modifier ce service ?')\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\tModifier
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-edit\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"sr-only\">Editer</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t</a>


\t\t\t\t\t\t\t\t\t\t\t\t\t{%if service.statut == 1 %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a class=\"btn btn-danger btn-sm\" href=\"{{ path('desabled_service', {id: service.id}) }}\" onclick=\"return confirm('Etes-vous sûr de vouloir desactiver ce service ?')\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tSupprimer
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-lock\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"sr-only\">delete</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t\t\t\t{%if service.statut == 0 %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a class=\"btn btn-success btn-sm\" href=\"{{ path('enable_service', {id: service.id}) }}\" onclick=\"return confirm('Etes-vous sûr de vouloir activer ce service ?')\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tActiver
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-unlock\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"sr-only\">activate</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t\t\t</td>


\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t\t</tbody>

\t\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<!-- /.card-body -->
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<!-- /.card -->

\t\t\t\t\t</div>
\t\t\t\t\t<!-- /.col -->
\t\t\t\t</div>
\t\t\t\t<!-- /.row -->
\t\t\t</div>

\t\t\t<!-- /.container-fluid -->
\t\t</section>
\t\t<!-- /.content -->

\t{% endblock %}
\t{% block autresFichiersJs %}
\t\t<!-- jQuery -->
\t\t<script src=\"{{ asset('plugins/jquery/jquery.min.js') }}\"></script>
\t\t<!-- Bootstrap 4 -->
\t\t<script src=\"{{ asset('plugins/bootstrap/js/bootstrap.bundle.min.js') }}\"></script>
\t\t<!-- DataTables  & Plugins -->
\t\t<script src=\"{{ asset('plugins/datatables/jquery.dataTables.min.js') }}\"></script>
\t\t<script src=\"{{ asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js') }}\"></script>
\t\t<script src=\"{{ asset('plugins/datatables-responsive/js/dataTables.responsive.min.js') }}\"></script>
\t\t<script src=\"{{ asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js') }}\"></script>
\t\t<script src=\"{{ asset('plugins/datatables-buttons/js/dataTables.buttons.min.js') }}\"></script>
\t\t<script src=\"{{ asset('plugins/datatables-buttons/js/buttons.bootstrap4.min.js') }}\"></script>
\t\t<script src=\"{{ asset('plugins/jszip/jszip.min.js') }}\"></script>
\t\t<script src=\"{{ asset('plugins/pdfmake/pdfmake.min.js') }}\"></script>
\t\t<script src=\"{{ asset('plugins/pdfmake/vfs_fonts.js') }}\"></script>
\t\t<script src=\"{{ asset('plugins/datatables-buttons/js/buttons.html5.min.js') }}\"></script>
\t\t<script src=\"{{ asset('plugins/datatables-buttons/js/buttons.print.min.js') }}\"></script>
\t\t<script src=\"{{ asset('plugins/datatables-buttons/js/buttons.colVis.min.js') }}\"></script>
\t\t<!-- AdminLTE App -->
\t\t<script src=\"{{ asset('dist/js/adminlte.min.js') }}\"></script>
\t\t<!-- AdminLTE for demo purposes -->
\t\t<script src=\"{{ asset('dist/js/demo.js') }}\"></script>
\t\t<!-- Page specific script -->
\t\t<script>
\t\t\t\$(function () {
\$(\"#service\").DataTable({
\"responsive\": true,
\"aaSorting\": [
[0, \"desc\"]
],
oLanguage: {
sSearch: \"Rechercher : \",
sZeroRecords: \"Aucune valeur trouvée\",
sInfo: \"Afficher page _PAGE_ sur _PAGES_\",
sInfoFiltered: \"(Filtres sur _MAX_ )\",
sInfoEmpty: \"\",
oPaginate: {
sFirst: \"Premier\",
sPrevious: \"Pr&eacute;c&eacute;dent\",
sNext: \"Suivant\",
sLast: \"Dernier\"
}
},
\"lengthChange\": false,
\"autoWidth\": false,
\"buttons\": [
\"copy\",
\"csv\",
\"excel\",
\"pdf\",
\"print\",
\"colvis\"
]
}).buttons().container().appendTo('#service_wrapper .col-md-6:eq(0)');

});
\t\t</script>
\t{% endblock %}
", "service/service.html.twig", "E:\\mes projets\\SuperAdmin\\templates\\service\\service.html.twig");
    }
}
