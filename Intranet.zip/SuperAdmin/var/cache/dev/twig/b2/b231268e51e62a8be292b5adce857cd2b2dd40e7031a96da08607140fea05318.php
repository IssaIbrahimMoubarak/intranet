<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* login.html.twig */
class __TwigTemplate_64ab6aeb249262c391a73013ea32b7673e2f4ddbb8cd7cdde65695a8c495d556 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 55
        return "layout_login.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "login.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "login.html.twig"));

        $this->parent = $this->loadTemplate("layout_login.html.twig", "login.html.twig", 55);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 58
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        // line 59
        echo "\tLogin
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 61
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 62
        echo "\t";
        if ((isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 62, $this->source); })())) {
            // line 63
            echo "\t\t<div class=\"alert alert-danger\" role=\"alert\">
\t\t\t";
            // line 64
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["message"]) || array_key_exists("message", $context) ? $context["message"] : (function () { throw new RuntimeError('Variable "message" does not exist.', 64, $this->source); })()), twig_get_attribute($this->env, $this->source, (isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 64, $this->source); })()), "messageData", [], "any", false, false, false, 64), "security"), "html", null, true);
            echo "
\t\t</div>
\t";
        }
        // line 67
        echo "\t<form class=\"row g-3 needs-validation\" novalidate action=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("fos_user_security_check");
        echo "\" method=\"post\">
\t\t";
        // line 68
        if ((isset($context["csrf_token"]) || array_key_exists("csrf_token", $context) ? $context["csrf_token"] : (function () { throw new RuntimeError('Variable "csrf_token" does not exist.', 68, $this->source); })())) {
            // line 69
            echo "\t\t\t<input type=\"hidden\" name=\"_csrf_token\" value=\"";
            echo twig_escape_filter($this->env, (isset($context["csrf_token"]) || array_key_exists("csrf_token", $context) ? $context["csrf_token"] : (function () { throw new RuntimeError('Variable "csrf_token" does not exist.', 69, $this->source); })()), "html", null, true);
            echo "\"/>
\t\t";
        }
        // line 71
        echo "
\t\t<div class=\"col-12\">
\t\t\t<label for=\"yourUsername\" class=\"form-label\">Username</label>
\t\t\t<div
\t\t\t\tclass=\"input-group has-validation\">
\t\t\t\t";
        // line 77
        echo "\t\t\t\t<input type=\"text\" name=\"_username\" class=\"form-control\" id=\"username\" required value=\"";
        echo twig_escape_filter($this->env, (isset($context["last_username"]) || array_key_exists("last_username", $context) ? $context["last_username"] : (function () { throw new RuntimeError('Variable "last_username" does not exist.', 77, $this->source); })()), "html", null, true);
        echo "\" required=\"required\" autocomplete=\"username\" placeholder=\"Nom d'utilisateur\">
\t\t\t\t<div class=\"invalid-feedback\">Please enter your username.</div>
\t\t\t</div>
\t\t</div>

\t\t<div class=\"col-12\">
\t\t\t<label for=\"yourPassword\" class=\"form-label\">Password</label>
\t\t\t<input type=\"password\" name=\"_password\" class=\"form-control\" id=\"password\" required autocomplete=\"current-password\" class=\"form-control\" placeholder=\"Mot de passe\">
\t\t\t<div class=\"invalid-feedback\">Please enter your password!</div>
\t\t</div>

\t\t<div class=\"col-12\">
\t\t\t<div class=\"form-check\">
\t\t\t\t<input class=\"form-check-input\" type=\"checkbox\" name=\"remember\" value=\"true\" id=\"rememberMe\">
\t\t\t\t<label class=\"form-check-label\" for=\"rememberMe\">Remember me</label>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"col-12\">
\t\t\t<button class=\"btn btn-primary w-100\" type=\"submit\">Connexions</button>
\t\t</div>
\t\t";
        // line 102
        echo "\t</form>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 104
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  158 => 104,  147 => 102,  123 => 77,  116 => 71,  110 => 69,  108 => 68,  103 => 67,  97 => 64,  94 => 63,  91 => 62,  81 => 61,  70 => 59,  60 => 58,  37 => 55,);
    }

    public function getSourceContext()
    {
        return new Source("{# {% extends 'layout_login.html.twig' %}
{% trans_default_domain 'FOSUserBundle' %}

{% block title %}
\tLogin
{% endblock %}
{% block body %}
\t<div class=\"card-body\">
\t\t<p class=\"login-box-msg\">Veuillez vous connecter</p>
\t\t{% if error %}
\t\t\t<div class=\"alert alert-danger\" role=\"alert\">
\t\t\t\t{{ message |trans(error.messageData, 'security') }}
\t\t\t</div>
\t\t{% endif %}
\t\t<form action=\"{{ path(\"fos_user_security_check\") }}\" method=\"post\">
\t\t\t{% if csrf_token %}
\t\t\t\t<input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token }}\"/>
\t\t\t{% endif %}
\t\t\t<div class=\"input-group mb-3 col-9\">
\t\t\t\t<input type=\"text\" id=\"username\" name=\"_username\" value=\"{{ last_username }}\" required=\"required\" autocomplete=\"username\" class=\"form-control\" placeholder=\"Nom d'utilisateur\"/>
\t\t\t\t<div class=\"input-group-append\">
\t\t\t\t\t<div class=\"input-group-text\">
\t\t\t\t\t\t<span class=\"fas fa-user\"></span>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<br>
\t\t\t<div class=\"input-group  col-9\">
\t\t\t\t<input type=\"password\" id=\"password\" name=\"_password\" required=\"required\" autocomplete=\"current-password\" class=\"form-control\" placeholder=\"Mot de passe\"/>
\t\t\t\t<div class=\"input-group-append\">
\t\t\t\t\t<div class=\"input-group-text\">
\t\t\t\t\t\t<span class=\"fas fa-lock\"></span>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<br>

\t\t\t<!-- /.col -->
\t\t\t<div class=\"col-4; background-position: center; \">
\t\t\t\t<center>
\t\t\t\t\t<button class=\"btn btn-success btn-sm\">Connexion</button>
\t\t\t\t</center>
\t\t\t</div>
\t\t\t<br>

\t\t\t<!-- /.col -->
\t\t</div>
\t</form>
\t<br/>


</div>
<!-- /.card-body -->{% endblock %}{% block footer %}{% endblock %} #}

{% extends 'layout_login.html.twig' %}
{% trans_default_domain 'FOSUserBundle' %}

{% block title %}
\tLogin
{% endblock %}
{% block body %}
\t{% if error %}
\t\t<div class=\"alert alert-danger\" role=\"alert\">
\t\t\t{{ message |trans(error.messageData, 'security') }}
\t\t</div>
\t{% endif %}
\t<form class=\"row g-3 needs-validation\" novalidate action=\"{{ path(\"fos_user_security_check\") }}\" method=\"post\">
\t\t{% if csrf_token %}
\t\t\t<input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token }}\"/>
\t\t{% endif %}

\t\t<div class=\"col-12\">
\t\t\t<label for=\"yourUsername\" class=\"form-label\">Username</label>
\t\t\t<div
\t\t\t\tclass=\"input-group has-validation\">
\t\t\t\t{# <span class=\"input-group-text\" id=\"inputGroupPrepend\">@</span> #}
\t\t\t\t<input type=\"text\" name=\"_username\" class=\"form-control\" id=\"username\" required value=\"{{ last_username }}\" required=\"required\" autocomplete=\"username\" placeholder=\"Nom d'utilisateur\">
\t\t\t\t<div class=\"invalid-feedback\">Please enter your username.</div>
\t\t\t</div>
\t\t</div>

\t\t<div class=\"col-12\">
\t\t\t<label for=\"yourPassword\" class=\"form-label\">Password</label>
\t\t\t<input type=\"password\" name=\"_password\" class=\"form-control\" id=\"password\" required autocomplete=\"current-password\" class=\"form-control\" placeholder=\"Mot de passe\">
\t\t\t<div class=\"invalid-feedback\">Please enter your password!</div>
\t\t</div>

\t\t<div class=\"col-12\">
\t\t\t<div class=\"form-check\">
\t\t\t\t<input class=\"form-check-input\" type=\"checkbox\" name=\"remember\" value=\"true\" id=\"rememberMe\">
\t\t\t\t<label class=\"form-check-label\" for=\"rememberMe\">Remember me</label>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"col-12\">
\t\t\t<button class=\"btn btn-primary w-100\" type=\"submit\">Connexions</button>
\t\t</div>
\t\t{# <div class=\"col-12\">
\t\t\t\t\t\t\t<p class=\"small mb-0\">Don't have account?
\t\t\t\t\t\t\t\t<a href=\"pages-register.html\">Create an account</a>
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t</div> #}
\t</form>
{% endblock %}
{% block footer %}{% endblock %}
", "login.html.twig", "E:\\mes projets\\SuperAdmin\\templates\\login.html.twig");
    }
}
