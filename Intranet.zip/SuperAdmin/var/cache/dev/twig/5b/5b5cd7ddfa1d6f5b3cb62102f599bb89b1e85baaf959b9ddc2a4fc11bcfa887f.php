<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* layout_login.html.twig */
class __TwigTemplate_7a3e8a24f404e2fdec5759030ef4d87a04802374f21b3973cf8785a16428f4a9 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "layout_login.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "layout_login.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">

\t<head>
\t\t<meta charset=\"utf-8\">
\t\t<meta content=\"width=device-width, initial-scale=1.0\" name=\"viewport\">

\t\t<title>
\t\t\t";
        // line 9
        $this->displayBlock('title', $context, $blocks);
        // line 11
        echo "\t\t</title>
\t\t<meta content=\"\" name=\"description\">
\t\t<meta
\t\tcontent=\"\" name=\"keywords\">

\t\t<!-- Favicons -->
\t\t<link href=\"assets/img/favicon.png\" rel=\"icon\">
\t\t<link
\t\thref=\"assets/img/apple-touch-icon.png\" rel=\"apple-touch-icon\">

\t\t<!-- Google Fonts -->
\t\t<link href=\"https://fonts.gstatic.com\" rel=\"preconnect\">
\t\t<link
\t\thref=\"https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i\" rel=\"stylesheet\">

\t\t<!-- Vendor CSS Files -->
\t\t<link href=\"assets/vendor/bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\">
\t\t<link href=\"assets/vendor/bootstrap-icons/bootstrap-icons.css\" rel=\"stylesheet\">
\t\t<link href=\"assets/vendor/boxicons/css/boxicons.min.css\" rel=\"stylesheet\">
\t\t<link href=\"assets/vendor/quill/quill.snow.css\" rel=\"stylesheet\">
\t\t<link href=\"assets/vendor/quill/quill.bubble.css\" rel=\"stylesheet\">
\t\t<link href=\"assets/vendor/remixicon/remixicon.css\" rel=\"stylesheet\">
\t\t<link
\t\thref=\"assets/vendor/simple-datatables/style.css\" rel=\"stylesheet\">

\t\t<!-- Template Main CSS File -->
\t\t<link
\t\thref=\"assets/css/style.css\" rel=\"stylesheet\">

\t<!-- =======================================================
\t\t\t\t\t\t\t  * Template Name: NiceAdmin - v2.3.1
\t\t\t\t\t\t\t  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
\t\t\t\t\t\t\t  * Author: BootstrapMade.com
\t\t\t\t\t\t\t  * License: https://bootstrapmade.com/license/
\t\t\t\t\t\t\t  ======================================================== -->
\t</head>

\t<body>

\t\t<main>
\t\t\t<div class=\"container\">

\t\t\t\t<section class=\"section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4\">
\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t<div class=\"col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center\">

\t\t\t\t\t\t\t\t<div class=\"d-flex justify-content-center py-4\">
\t\t\t\t\t\t\t\t\t<a href=\"index.html\" class=\"logo d-flex align-items-center w-auto\">
\t\t\t\t\t\t\t\t\t\t<img src=\"assets/img/logo.png\" alt=\"\">
\t\t\t\t\t\t\t\t\t\t<span class=\"d-none d-lg-block\">Intranet</span>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<!-- End Logo -->


\t\t\t\t\t\t\t\t<a href=\"";
        // line 67
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        echo "\" class=\"h1\">
\t\t\t\t\t\t\t\t\t<b></b>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t";
        // line 70
        $this->displayBlock('body', $context, $blocks);
        // line 71
        echo "\t\t\t\t\t\t\t\t<div class=\"credits\"><!-- All the links in the footer should remain intact. -->
\t\t\t\t\t\t\t\t\t<!-- You can delete the links only if you purchased the pro version. -->
\t\t\t\t\t\t\t\t\t<!-- Licensing information: https://bootstrapmade.com/license/ -->
\t\t\t\t\t\t\t\t\t<!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
\t\t\t\t\t\t\t\t\t";
        // line 77
        echo "\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>

\t\t\t\t</section>

\t\t\t</div>
\t\t</main>
\t\t<!-- End #main -->

\t\t<a href=\"#\" class=\"back-to-top d-flex align-items-center justify-content-center\">
\t\t\t<i class=\"bi bi-arrow-up-short\"></i>
\t\t</a>

\t\t<!-- Vendor JS Files -->
\t\t<script src=\"assets/vendor/apexcharts/apexcharts.min.js\"></script>
\t\t<script src=\"assets/vendor/bootstrap/js/bootstrap.bundle.min.js\"></script>
\t\t<script src=\"assets/vendor/chart.js/chart.min.js\"></script>
\t\t<script src=\"assets/vendor/echarts/echarts.min.js\"></script>
\t\t<script src=\"assets/vendor/quill/quill.min.js\"></script>
\t\t<script src=\"assets/vendor/simple-datatables/simple-datatables.js\"></script>
\t\t<script src=\"assets/vendor/tinymce/tinymce.min.js\"></script>
\t\t<script src=\"assets/vendor/php-email-form/validate.js\"></script>

\t\t<!-- Template Main JS File -->
\t\t<script src=\"assets/js/main.js\"></script>

\t</body>

</html>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 9
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Intranet
\t\t\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 70
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "layout_login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  191 => 70,  171 => 9,  129 => 77,  123 => 71,  121 => 70,  115 => 67,  57 => 11,  55 => 9,  45 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\">

\t<head>
\t\t<meta charset=\"utf-8\">
\t\t<meta content=\"width=device-width, initial-scale=1.0\" name=\"viewport\">

\t\t<title>
\t\t\t{% block title %}Intranet
\t\t\t{% endblock %}
\t\t</title>
\t\t<meta content=\"\" name=\"description\">
\t\t<meta
\t\tcontent=\"\" name=\"keywords\">

\t\t<!-- Favicons -->
\t\t<link href=\"assets/img/favicon.png\" rel=\"icon\">
\t\t<link
\t\thref=\"assets/img/apple-touch-icon.png\" rel=\"apple-touch-icon\">

\t\t<!-- Google Fonts -->
\t\t<link href=\"https://fonts.gstatic.com\" rel=\"preconnect\">
\t\t<link
\t\thref=\"https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i\" rel=\"stylesheet\">

\t\t<!-- Vendor CSS Files -->
\t\t<link href=\"assets/vendor/bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\">
\t\t<link href=\"assets/vendor/bootstrap-icons/bootstrap-icons.css\" rel=\"stylesheet\">
\t\t<link href=\"assets/vendor/boxicons/css/boxicons.min.css\" rel=\"stylesheet\">
\t\t<link href=\"assets/vendor/quill/quill.snow.css\" rel=\"stylesheet\">
\t\t<link href=\"assets/vendor/quill/quill.bubble.css\" rel=\"stylesheet\">
\t\t<link href=\"assets/vendor/remixicon/remixicon.css\" rel=\"stylesheet\">
\t\t<link
\t\thref=\"assets/vendor/simple-datatables/style.css\" rel=\"stylesheet\">

\t\t<!-- Template Main CSS File -->
\t\t<link
\t\thref=\"assets/css/style.css\" rel=\"stylesheet\">

\t<!-- =======================================================
\t\t\t\t\t\t\t  * Template Name: NiceAdmin - v2.3.1
\t\t\t\t\t\t\t  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
\t\t\t\t\t\t\t  * Author: BootstrapMade.com
\t\t\t\t\t\t\t  * License: https://bootstrapmade.com/license/
\t\t\t\t\t\t\t  ======================================================== -->
\t</head>

\t<body>

\t\t<main>
\t\t\t<div class=\"container\">

\t\t\t\t<section class=\"section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4\">
\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t<div class=\"col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center\">

\t\t\t\t\t\t\t\t<div class=\"d-flex justify-content-center py-4\">
\t\t\t\t\t\t\t\t\t<a href=\"index.html\" class=\"logo d-flex align-items-center w-auto\">
\t\t\t\t\t\t\t\t\t\t<img src=\"assets/img/logo.png\" alt=\"\">
\t\t\t\t\t\t\t\t\t\t<span class=\"d-none d-lg-block\">Intranet</span>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<!-- End Logo -->


\t\t\t\t\t\t\t\t<a href=\"{{ path(\"login\") }}\" class=\"h1\">
\t\t\t\t\t\t\t\t\t<b></b>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t{% block body %}{% endblock %}
\t\t\t\t\t\t\t\t<div class=\"credits\"><!-- All the links in the footer should remain intact. -->
\t\t\t\t\t\t\t\t\t<!-- You can delete the links only if you purchased the pro version. -->
\t\t\t\t\t\t\t\t\t<!-- Licensing information: https://bootstrapmade.com/license/ -->
\t\t\t\t\t\t\t\t\t<!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
\t\t\t\t\t\t\t\t\t{# Designed by
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"https://bootstrapmade.com/\"> Nasty</a> #}
\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>

\t\t\t\t</section>

\t\t\t</div>
\t\t</main>
\t\t<!-- End #main -->

\t\t<a href=\"#\" class=\"back-to-top d-flex align-items-center justify-content-center\">
\t\t\t<i class=\"bi bi-arrow-up-short\"></i>
\t\t</a>

\t\t<!-- Vendor JS Files -->
\t\t<script src=\"assets/vendor/apexcharts/apexcharts.min.js\"></script>
\t\t<script src=\"assets/vendor/bootstrap/js/bootstrap.bundle.min.js\"></script>
\t\t<script src=\"assets/vendor/chart.js/chart.min.js\"></script>
\t\t<script src=\"assets/vendor/echarts/echarts.min.js\"></script>
\t\t<script src=\"assets/vendor/quill/quill.min.js\"></script>
\t\t<script src=\"assets/vendor/simple-datatables/simple-datatables.js\"></script>
\t\t<script src=\"assets/vendor/tinymce/tinymce.min.js\"></script>
\t\t<script src=\"assets/vendor/php-email-form/validate.js\"></script>

\t\t<!-- Template Main JS File -->
\t\t<script src=\"assets/js/main.js\"></script>

\t</body>

</html>
", "layout_login.html.twig", "E:\\mes projets\\SuperAdmin\\templates\\layout_login.html.twig");
    }
}
