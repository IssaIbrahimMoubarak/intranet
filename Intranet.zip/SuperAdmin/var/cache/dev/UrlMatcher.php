<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'accueil', '_controller' => 'App\\Controller\\AccueilController::accueil'], null, null, null, false, false, null]],
        '/direction' => [[['_route' => 'list_direction', '_controller' => 'App\\Controller\\DirectionController::Direction'], null, null, null, false, false, null]],
        '/direction/new' => [[['_route' => 'create_direction', '_controller' => 'App\\Controller\\DirectionController::createDirection'], null, null, null, false, false, null]],
        '/login1' => [[['_route' => 'login1', '_controller' => 'App\\Controller\\SecurityController::login'], null, null, null, true, false, null]],
        '/service' => [[['_route' => 'list_service', '_controller' => 'App\\Controller\\ServiceController::Service'], null, null, null, false, false, null]],
        '/service/new' => [[['_route' => 'create_service', '_controller' => 'App\\Controller\\ServiceController::createService'], null, null, null, false, false, null]],
        '/chef' => [[['_route' => 'list_chef', '_controller' => 'App\\Controller\\SuperAdminController::Chef'], null, null, null, false, false, null]],
        '/Agent' => [[['_route' => 'list_agent', '_controller' => 'App\\Controller\\SuperAdminController::Agent'], null, null, null, false, false, null]],
        '/chef/new' => [[['_route' => 'create_chef', '_controller' => 'App\\Controller\\SuperAdminController::createChef'], null, null, null, false, false, null]],
        '/agent/new' => [[['_route' => 'create_agent', '_controller' => 'App\\Controller\\SuperAdminController::createAgent'], null, null, null, false, false, null]],
        '/user' => [[['_route' => 'list_user', '_controller' => 'App\\Controller\\UserController::user'], null, null, null, false, false, null]],
        '/user/new' => [[['_route' => 'create_user', '_controller' => 'App\\Controller\\UserController::createUser'], null, null, null, false, false, null]],
        '/logout' => [
            [['_route' => 'logout', '_controller' => 'App\\Controller\\UserController::logoutAction'], null, null, null, false, false, null],
            [['_route' => 'fos_user_security_logout', '_controller' => 'fos_user.security.controller:logoutAction'], null, ['GET' => 0, 'POST' => 1], null, false, false, null],
        ],
        '/user/editpassword' => [[['_route' => 'edit_password', '_controller' => 'App\\Controller\\UserController::editPassword'], null, null, null, false, false, null]],
        '/login' => [
            [['_route' => 'login', '_controller' => 'App\\Controller\\UserController::login'], null, null, null, false, false, null],
            [['_route' => 'fos_user_security_login', '_controller' => 'fos_user.security.controller:loginAction'], null, ['GET' => 0, 'POST' => 1], null, false, false, null],
        ],
        '/user/resetpassword' => [[['_route' => 'reset_password', '_controller' => 'App\\Controller\\UserController::resetPassword'], null, null, null, false, false, null]],
        '/login_check' => [[['_route' => 'fos_user_security_check', '_controller' => 'fos_user.security.controller:checkAction'], null, ['POST' => 0], null, false, false, null]],
        '/profile' => [[['_route' => 'fos_user_profile_show', '_controller' => 'fos_user.profile.controller:showAction'], null, ['GET' => 0], null, true, false, null]],
        '/profile/edit' => [[['_route' => 'fos_user_profile_edit', '_controller' => 'fos_user.profile.controller:editAction'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/register' => [[['_route' => 'fos_user_registration_register', '_controller' => 'fos_user.registration.controller:registerAction'], null, ['GET' => 0, 'POST' => 1], null, true, false, null]],
        '/register/check-email' => [[['_route' => 'fos_user_registration_check_email', '_controller' => 'fos_user.registration.controller:checkEmailAction'], null, ['GET' => 0], null, false, false, null]],
        '/register/confirmed' => [[['_route' => 'fos_user_registration_confirmed', '_controller' => 'fos_user.registration.controller:confirmedAction'], null, ['GET' => 0], null, false, false, null]],
        '/resetting/request' => [[['_route' => 'fos_user_resetting_request', '_controller' => 'fos_user.resetting.controller:requestAction'], null, ['GET' => 0], null, false, false, null]],
        '/resetting/send-email' => [[['_route' => 'fos_user_resetting_send_email', '_controller' => 'fos_user.resetting.controller:sendEmailAction'], null, ['POST' => 0], null, false, false, null]],
        '/resetting/check-email' => [[['_route' => 'fos_user_resetting_check_email', '_controller' => 'fos_user.resetting.controller:checkEmailAction'], null, ['GET' => 0], null, false, false, null]],
        '/profile/change-password' => [[['_route' => 'fos_user_change_password', '_controller' => 'fos_user.change_password.controller:changePasswordAction'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:102)'
                            .'|router(*:116)'
                            .'|exception(?'
                                .'|(*:136)'
                                .'|\\.css(*:149)'
                            .')'
                        .')'
                        .'|(*:159)'
                    .')'
                .')'
                .'|/d(?'
                    .'|irection/edit/([^/]++)(*:196)'
                    .'|esactiver/([^/]++)(?'
                        .'|(*:225)'
                    .')'
                .')'
                .'|/a(?'
                    .'|ctiver/([^/]++)(?'
                        .'|(*:258)'
                    .')'
                    .'|gent/edit/([^/]++)(*:285)'
                .')'
                .'|/service/edit/([^/]++)(*:316)'
                .'|/chef/edit/([^/]++)(*:343)'
                .'|/user/edit/([^/]++)(*:370)'
                .'|/qr\\-code/([^/]++)/([^/]++)(*:405)'
                .'|/re(?'
                    .'|gister/confirm/([^/]++)(*:442)'
                    .'|setting/reset/([^/]++)(*:472)'
                .')'
            .')/?$}sD',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        102 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        116 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        136 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        149 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        159 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        196 => [[['_route' => 'edit_direction', '_controller' => 'App\\Controller\\DirectionController::editDirection'], ['id'], null, null, false, true, null]],
        225 => [
            [['_route' => 'desabled_direction', '_controller' => 'App\\Controller\\DirectionController::desactiverDirection'], ['id'], null, null, false, true, null],
            [['_route' => 'desabled_service', '_controller' => 'App\\Controller\\ServiceController::desactiverService'], ['id'], null, null, false, true, null],
            [['_route' => 'desabled_chef', '_controller' => 'App\\Controller\\SuperAdminController::desactiverChef'], ['id'], null, null, false, true, null],
            [['_route' => 'desabled_agent', '_controller' => 'App\\Controller\\SuperAdminController::desactiverAgent'], ['id'], null, null, false, true, null],
            [['_route' => 'desabled_user', '_controller' => 'App\\Controller\\UserController::desactiverUser'], ['id'], null, null, false, true, null],
        ],
        258 => [
            [['_route' => 'enable_direction', '_controller' => 'App\\Controller\\DirectionController::activerDirection'], ['id'], null, null, false, true, null],
            [['_route' => 'enable_service', '_controller' => 'App\\Controller\\ServiceController::activerService'], ['id'], null, null, false, true, null],
            [['_route' => 'enable_chef', '_controller' => 'App\\Controller\\SuperAdminController::activerChef'], ['id'], null, null, false, true, null],
            [['_route' => 'enable_agent', '_controller' => 'App\\Controller\\SuperAdminController::activerAgent'], ['id'], null, null, false, true, null],
        ],
        285 => [[['_route' => 'edit_agent', '_controller' => 'App\\Controller\\SuperAdminController::editAgent'], ['id'], null, null, false, true, null]],
        316 => [[['_route' => 'edit_service', '_controller' => 'App\\Controller\\ServiceController::editService'], ['id'], null, null, false, true, null]],
        343 => [[['_route' => 'edit_chef', '_controller' => 'App\\Controller\\SuperAdminController::editChef'], ['id'], null, null, false, true, null]],
        370 => [[['_route' => 'edit_user', '_controller' => 'App\\Controller\\UserController::editUser'], ['id'], null, null, false, true, null]],
        405 => [[['_route' => 'qr_code_generate', '_controller' => 'Endroid\\QrCodeBundle\\Controller\\GenerateController'], ['builder', 'data'], null, null, false, true, null]],
        442 => [[['_route' => 'fos_user_registration_confirm', '_controller' => 'fos_user.registration.controller:confirmAction'], ['token'], ['GET' => 0], null, false, true, null]],
        472 => [
            [['_route' => 'fos_user_resetting_reset', '_controller' => 'fos_user.resetting.controller:resetAction'], ['token'], ['GET' => 0, 'POST' => 1], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
